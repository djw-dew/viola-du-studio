// 修改个人信息、简历和 Demo 后，保存并刷新网页。
// 简历资料来自 DJW_CV_10.21.pdf；已发表、已接收、投稿中和早期探索分别标注。
window.STUDIO = {
  name: 'Viola Du',
  title: 'Viola Du’s studio',
  email: '13251891573@163.com',
  resume: {
    headline: '杜佳蔚 Jiawei Du',
    introduction: '北京协和医学院遗传学硕士在读，预计 2027 年毕业。关注遗传学与转录组学、虚拟细胞建模、扰动响应预测及 AI 辅助药物发现，正在探索生成模型与多模态学习，重视生物学解释和严谨的模型评估。',
    pdf: 'assets/viola-du-resume.pdf?v=cv-20261021',
    education: [
      { title: '北京协和医学院', subtitle: '硕士 · 遗传学｜平均成绩 88/100', period: '2024.09 — 2027.06（预计）', description: '研究兴趣：机器学习与深度学习、虚拟细胞建模、扰动响应预测、多模态生物医学建模及 AI 辅助药物发现。' },
      { title: '大连民族大学', subtitle: '本科 · 食品质量与安全｜工学学士｜GPA 3.02/5.0', period: '2020.09 — 2024.06', description: '' }
    ],
    experience: [
      { title: 'Atcay G39S 突变的小脑单核转录组与计算扰动分析', subtitle: '研究论文 · 第一作者 · 投稿中', description: '分析 3 只野生型与 3 只突变大鼠的 93,334 个小脑细胞核，结合细胞类型注释、校正性别因素的动物水平 pseudobulk 分析和通路富集。构建野生型表达网络，开展 Atcay 计算扰动，并通过基线比较、匹配对照、平衡重采样和逐只动物留出分析评估预测；区分网络预测与实测转录变化，明确靶点特异性响应恢复的局限。' },
      { title: 'ATCAY 相关开曼型共济失调的致病机制与基因治疗', subtitle: '硕士毕业课题 · 在研', description: '整合单细胞转录组、分子表征和超微结构分析，研究 Atcay 突变模型的阶段性小脑病理，关注早期突触与钙信号转录失调，以及后期少突胶质细胞脂质与固醇重塑、髓鞘异常和浦肯野细胞功能障碍。' },
      { title: '基于转录组的虚拟细胞建模', subtitle: '早期探索 · 条件生成模型', description: '基于单核转录组和计算扰动分析经验，探索利用条件生成模型预测扰动引起的转录响应。' },
      { title: '药物靶点相关科研 Agent', subtitle: '个人项目 · Dify Chatflow', description: '构建药物靶点相关的 Agent 工作流，辅助科研信息整理。可在 Demo 页面体验靶点调研与疾病驱动的小分子靶点评估工具。' }
    ],
    highlights: [
      'Human Genetics（2025）｜第二作者 · 已发表：研究 4p16.1 非复发性重复与孤立性双侧小耳畸形，结合生物信息学及双荧光素酶实验分析顺式调控元件。DOI：10.1007/s00439-025-02788-0。',
      'Genes（2026）｜第一作者 · 综述已接收：Precision Gene Therapy for Monogenic Neurological Disorders: From Advanced AAV Engineering to Next-Generation Genomic Toolkits。',
      'Atcay G39S 小脑单核转录组研究｜第一作者 · 投稿中：Single-Nucleus Transcriptomics Reveals Cell-Type-Specific Cerebellar Responses to the Atcay G39S Mutation in Rats。'
    ],
    skills: ['Python / R', '基因编辑', '单细胞组学', '基因组学', 'AIDD', 'Bulk / 单核 RNA-seq', 'Pseudobulk 分析', '通路富集', '计算扰动分析', 'Dify Chatflow']
  },
  demos: [
    {
      id: 'target-research', title: '靶点调研信息整合 Agent', category: 'RESEARCH & EVIDENCE',
      description: '从一个靶点出发，连接蛋白功能、疾病关联与文献证据，让科研调研更有条理。',
      tags: ['靶点调研', '多源信息整合', '科研 Agent'],
      url: 'https://udify.app/chat/OmVkV2a1NfGbL4Wp', status: 'live',
      image: 'assets/demo-research.svg', imageAlt: '粉色研究工作台：基因靶点连接文献、蛋白与证据卡片'
    },
    {
      id: 'disease-target', title: '疾病驱动的小分子靶点评估 Agent', category: 'DISEASE & DISCOVERY',
      description: '从疾病问题出发，探索小分子靶点的评估思路。',
      tags: ['疾病驱动', '小分子', '靶点评估'],
      url: 'https://udify.app/workflow/gp3H3zmPsYISUdku', status: 'live',
      image: 'assets/demo-discovery.svg', imageAlt: '浅紫色实验笔记：疾病线索、分子结构与评估清单'
    }
  ]
};
